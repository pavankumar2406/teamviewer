# Getting Started
# Order Enricher Microservice

#Overview

This Spring Boot microservice receives raw order events, enriches them with customer and product data (mocked in-memory), stores them in PostgreSQL, and exposes enriched orders through REST APIs.

---

#Features

- POST `/orders` Accepts raw orders (`orderId`, `customerId`, `productIds`, `timestamp`)
- GET `/orders/{orderId}`  Returns enriched order with customer & product details
- GET `/orders?customerId=X` or `?productId=Y` (Bonus) Filter by customer or product
- Data enrichment from in-memory services
- Data persistence using PostgreSQL
- Docker support for containerization
- Unit tests for controller, service, repository layers

---

#Project Structure

```bash
src/
 └── main/
     ├── java/com/example/orderenricher/
     │   ├── controller/         # REST controllers
     │   ├── model/              # DTOs / Entities
     │   ├── service/            # Business logic
     │   ├── repository/         # Spring Data JPA repositories
     │   └── OrderenricherApplication.java
     └── resources/
         ├── application.properties
 └── test/
     └── java/com/example/orderenricher/
         ├── controller/OrderControllerTest.java
         ├── service/OrderServiceTest.java
         ├── repository/EnrichedOrderRepositoryTest.java


