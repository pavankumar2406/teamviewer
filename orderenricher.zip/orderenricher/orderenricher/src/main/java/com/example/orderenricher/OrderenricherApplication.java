package com.example.orderenricher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderenricherApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderenricherApplication.class, args);
	}

}
